import csv
import sys
import os

def convert_row(row):
    # ---------------------------------------------------
    # FRECUENCIAS
    # ---------------------------------------------------
    rx = float(row['Frequency'])
    duplex = row['Duplex']

    # OFFSET SIEMPRE COMO FLOAT
    try:
        offset = float(row['Offset'])
    except:
        offset = 0.0

    if duplex == 'split':
        tx = offset
    elif duplex == '+':
        tx = rx + offset
    elif duplex == '-':
        tx = rx - offset
    else:
        tx = rx

    # ---------------------------------------------------
    # TONOS
    # ---------------------------------------------------
    mode = row['Tone']          # "TSQL", "Tone", "DTCS", "Cross", ""
    r = str(row['rToneFreq'])   # TX
    c = str(row['cToneFreq'])   # RX
    code = str(row['DtcsCode'])
    pol = str(row['DtcsPolarity'])
    cross = row['CrossMode']

    # ---- CROSS MODE REAL (solo si Tone == "Cross") ----
    if mode == "Cross":
        if cross == "Tone->Tone":
            tone_rx = c
            tone_tx = r
        else:
            tone_rx = "OFF"
            tone_tx = "OFF"

    # ---- TSQL → usar SIEMPRE cToneFreq ----
    elif mode == "TSQL":
        tone_rx = c
        tone_tx = c

    # ---- TONE ----
    elif mode == "Tone":
        tone_rx = "OFF"
        tone_tx = r

    # ---- DTCS ----
    elif mode == "DTCS":
        pol_out = "N" if pol == "NN" else "I"
        tone_rx = f"D{code.zfill(3)}{pol_out}"
        tone_tx = tone_rx

    else:
        tone_rx = "OFF"
        tone_tx = "OFF"

    # ---------------------------------------------------
    # BANDWIDTH
    # ---------------------------------------------------
    bw = "Narrow" if row['Mode'] == "NFM" else "Wide"

    # ---------------------------------------------------
    # POWER
    # ---------------------------------------------------
    pwr_raw = row['Power'].upper()
    if "5" in pwr_raw or "4" in pwr_raw or "HIGH" in pwr_raw:
        power = "High"
    else:
        power = "Low"

    # ---------------------------------------------------
    # NAME
    # ---------------------------------------------------
    name = row['Name'][:12].upper()

    # ---------------------------------------------------
    # SALIDA FINAL
    # ---------------------------------------------------
    return [
        f"{rx:.5f}",
        f"{tx:.5f}",
        tone_rx,
        tone_tx,
        power,
        bw,
        "ADD",
        "OFF",
        "OFF",
        "OFF",
        "OFF",
        name
    ]


def main():

    if len(sys.argv) < 2:
        print("Arrastrá un archivo CSV del UV17R/CHIRP sobre este script.")
        sys.exit(1)

    infile = sys.argv[1]
    outname = "converted.csv"

    # DEBUG EN CASO DE PROBLEMAS
    print("Leyendo archivo:", infile)

    with open(infile, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print("Filas leídas:", len(rows))

    out_rows = []

    for row in rows:
        out_rows.append(convert_row(row))

    with open(outname, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(out_rows)

    print(f"✔ Archivo generado correctamente: {outname}")
    print("Ubicación:", os.path.abspath(outname))


if __name__ == "__main__":
    main()
