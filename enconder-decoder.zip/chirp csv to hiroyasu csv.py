import csv
import sys
import os

def convert_row(row):
    # FRECUENCIAS
    rx = float(row['Frequency'])
    duplex = row['Duplex']
    offset = row['Offset']

    if duplex == 'split':
        tx = float(offset)
    elif duplex == '+':
        tx = rx + float(offset)
    elif duplex == '-':
        tx = rx - float(offset)
    else:
        tx = rx

    # TONOS
    mode = row['Tone']
    r = str(row['rToneFreq'])
    c = str(row['cToneFreq'])
    code = str(row['DtcsCode'])
    pol = str(row['DtcsPolarity'])

    # --- NUEVA LÓGICA CROSS ---
    if mode == 'Cross':
        tone_rx = c   # RX → cToneFreq
        tone_tx = r   # TX → rToneFreq

    elif mode == 'TSQL':
        tone_rx = r
        tone_tx = c

    elif mode == 'Tone':
        tone_rx = 'OFF'
        tone_tx = r

    elif mode == 'DTCS':
        pol_out = 'N' if pol == 'NN' else 'I'
        tone_rx = f"D{code.zfill(3)}{pol_out}"
        tone_tx = tone_rx

    else:
        # OFF total
        tone_rx = 'OFF'
        tone_tx = 'OFF'

    # BANDWIDTH
    bw = 'Narrow' if row['Mode'] == 'NFM' else 'Wide'

    # POWER
    power = 'High' if row['Power'] == '4.0W' else 'Low'

    # NAME
    name = row['Name']

    return [
        f"{rx:.5f}",
        f"{tx:.5f}",
        tone_rx,
        tone_tx,
        power,
        bw,
        "ADD",
        "OFF",
        "OFF",
        "OFF",
        "OFF",
        name
    ]


def main():

    if len(sys.argv) < 2:
        print("Arrastrá un archivo CSV del Baofeng sobre este script.")
        sys.exit(1)

    infile = sys.argv[1]
    outname = "converted.csv"

    with open(infile, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    out_rows = []

    for row in rows:
        out_rows.append(convert_row(row))

    with open(outname, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(out_rows)

    print(f"✔ Archivo generado: {outname}")


if __name__ == "__main__":
    main()
