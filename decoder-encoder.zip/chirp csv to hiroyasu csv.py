import csv
import sys
import os

def convert_row(row):
    # ---------------------------------------------------
    # FRECUENCIAS
    # ---------------------------------------------------
    rx = float(row['Frequency'])
    duplex = row['Duplex']
    offset = row['Offset']

    if duplex == 'split':
        tx = float(offset)
    elif duplex == '+':
        tx = rx + float(offset)
    elif duplex == '-':
        tx = rx - float(offset)
    else:
        tx = rx

    # ---------------------------------------------------
    # TONOS
    # ---------------------------------------------------
    mode = row['Tone']
    r = str(row['rToneFreq'])
    c = str(row['cToneFreq'])
    code = str(row['DtcsCode'])
    pol = str(row['DtcsPolarity'])

    # ---- CROSS ----
    if mode == 'Cross':
        # RX usa cToneFreq, TX usa rToneFreq
        tone_rx = c
        tone_tx = r

    # ---- TSQL ----
    elif mode == 'TSQL':
        # Solo tono en TX, RX sin tono
        tone_rx = 'OFF'
        tone_tx = c

    # ---- TONE ----
    elif mode == 'Tone':
        tone_rx = 'OFF'
        tone_tx = r

    # ---- DTCS ----
    elif mode == 'DTCS':
        pol_out = 'N' if pol == 'NN' else 'I'
        tone_rx = f"D{code.zfill(3)}{pol_out}"
        tone_tx = tone_rx

    # ---- OFF u otros ----
    else:
        tone_rx = 'OFF'
        tone_tx = 'OFF'

    # ---------------------------------------------------
    # BANDWIDTH
    # ---------------------------------------------------
    bw = 'Narrow' if row['Mode'] == 'NFM' else 'Wide'

    # ---------------------------------------------------
    # POWER
    # ---------------------------------------------------
    power = 'High' if row['Power'] == '4.0W' else 'Low'

    # ---------------------------------------------------
    # NAME
    # ---------------------------------------------------
    name = row['Name']

    # ---------------------------------------------------
    # SALIDA FINAL (orden Hiroyasu)
    # ---------------------------------------------------
    return [
        f"{rx:.5f}",
        f"{tx:.5f}",
        tone_rx,
        tone_tx,
        power,
        bw,
        "ADD",
        "OFF",
        "OFF",
        "OFF",
        "OFF",
        name
    ]



def main():

    if len(sys.argv) < 2:
        print("Arrastrá un archivo CSV del Baofeng/CHIRP sobre este script.")
        sys.exit(1)

    infile = sys.argv[1]
    outname = "converted.csv"

    with open(infile, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    out_rows = []

    for row in rows:
        out_rows.append(convert_row(row))

    with open(outname, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(out_rows)

    print(f"✔ Archivo generado: {outname}")



if __name__ == "__main__":
    main()
